"use client";

export default function imageLoader({ src }: { src: string }) {
  return `/swipe${src}`;
}
