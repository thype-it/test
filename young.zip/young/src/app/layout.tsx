import type { Metadata } from "next";
import localFont from "next/font/local";
import "../globals.css";
import "../remote_menu.css";
import { GoogleTagManager } from "@next/third-parties/google";
import Script from "next/script";
import Footer from "./components/views/footer/Footer";
import ChatBubble from "./components/views/bubble/ChatBubble";
import Header from "./components/views/header/Header";

export const metadata: Metadata = {
  title: "Swipe",
  description: "Swipe",
};

const teleneo = localFont({
  src: [
    {
      path: "../../public/fonts/TeleNeoWeb-Regular.woff2",
      weight: "400",
      style: "normal",
    },
    {
      path: "../../public/fonts/TeleNeoWeb-RegularItalic.woff2",
      weight: "400",
      style: "italic",
    },
    {
      path: "../../public/fonts/TeleNeoWeb-Medium.woff2",
      weight: "500",
      style: "normal",
    },
    {
      path: "../../public/fonts/TeleNeoWeb-MediumItalic.woff2",
      weight: "500",
      style: "italic",
    },
    {
      path: "../../public/fonts/TeleNeoWeb-Bold.woff2",
      weight: "700",
      style: "normal",
    },
    {
      path: "../../public/fonts/TeleNeoWeb-BoldItalic.woff2",
      weight: "700",
      style: "italic",
    },
    {
      path: "../../public/fonts/TeleNeoWeb-ExtraBold.woff2",
      weight: "800",
      style: "normal",
    },
    {
      path: "../../public/fonts/TeleNeoWeb-ExtraBoldItalic.woff2",
      weight: "800",
      style: "italic",
    },
  ],
  display: "swap",
  variable: "--font-teleneo",
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${teleneo.variable}`}>
      <body>
        <Header />
        {children}
        <Footer />
        <ChatBubble />
      </body>
      <GoogleTagManager gtmId="GTM-WW7D6K" />
      <Script src="https://tchat-api.telekom.sk/young_light/bubble.js?id=young_light" />
      <Script src="//www.telekom.sk/appgui/menu/js/remote_menu.js?v=0.3" />
    </html>
  );
}
