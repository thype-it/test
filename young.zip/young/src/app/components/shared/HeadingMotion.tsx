"use client";

import { cn } from "@/lib/utils";
import { motion, useInView } from "framer-motion";
import React, { useRef } from "react";

type Props = {
  /**
   * Defaults to `2`
   */
  level?: 1 | 2 | 3 | 4 | 5;
  children: React.ReactNode;
  className?: string;
};

export default function HeadingMotion({ level = 2, children, className }: Props) {
  const Heading = `h${level}` as keyof JSX.IntrinsicElements;
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { margin: "0px 0px -200px 0px", once: true });

  const variants = {
    visible: {
      opacity: [0, 1, 1],
      letterSpacing: ["-1px", "4px", "4px"],
      transition: {
        duration: 2,
        times: [0, 0.3, 1],
      },
      transitionEnd: {
        opacity: 1,
      },
    },
    hidden: {
      opacity: 0,
    },
  };

  return (
    <motion.div
      className="relative"
      initial={{ opacity: 0 }}
      ref={ref}
      variants={variants}
      animate={isInView ? "visible" : "hidden"}
    >
      <Heading
        className={cn(
          "w-full text-center font-teleneo text-3xl font-extrabold uppercase text-primary",
          className,
        )}
      >
        {children}
      </Heading>
    </motion.div>
  );
}
