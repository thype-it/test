import { cn } from "@/lib/utils";
import { ReactNode } from "react";
import Image from "next/image";

export enum ButtonVariant {
  primary,
  secondary,
}

type Props = {
  variant?: ButtonVariant;
  fullWidth?: boolean;
  isDisabled?: boolean;
  children?: ReactNode;
  onPress?: () => void;
  className?: string;
};

export default function Button({
  variant = ButtonVariant.primary,
  fullWidth,
  isDisabled = false,
  children,
  onPress,
  className,
}: Props) {
  const buttonStyles = useButtonStyles;
  const textStyles = useTextStyles;

  const buttonVariantStyle = getButtonStyle(variant);
  const textVariantStyle = getTextStyle(variant);

  return (
    <button
      type="button"
      onClick={onPress}
      className={cn(
        `flex h-14 shrink-0 items-center justify-center gap-2 rounded-[6.8125rem] px-8 py-[1.125rem]
        shadow-[-3px_-4px_7px_0px_rgba(255,255,255,0.30)_inset]`,
        buttonVariantStyle.base,
        isDisabled && buttonVariantStyle.disabled,
        fullWidth && "w-full",
        className,
      )}
    >
      <p
        className={cn(
          "font-teleneo text-sm/[1rem] font-extrabold uppercase tracking-[0.00875rem]",
          textVariantStyle.base,
          isDisabled && textVariantStyle.disabled,
        )}
      >
        {children}
      </p>
    </button>
  );

  function getButtonStyle(variant: ButtonVariant) {
    switch (variant) {
      case ButtonVariant.primary: {
        return buttonStyles.primaryButton;
      }
      case ButtonVariant.secondary: {
        return buttonStyles.secondaryButton;
      }
    }
  }

  function getTextStyle(variant: ButtonVariant) {
    switch (variant) {
      case ButtonVariant.primary: {
        return textStyles.primaryText;
      }
      case ButtonVariant.secondary: {
        return textStyles.secondaryText;
      }
    }
  }
}

export enum ButtonDirection {
  left,
  right,
}

type DirectionButtonProps = {
  direction?: ButtonDirection;
  onPress?: () => void;
  className?: string;
  isDisabled?: boolean;
};

export function DirectionButton({
  direction = ButtonDirection.left,
  onPress,
  className,
  isDisabled = false,
}: DirectionButtonProps) {
  return (
    <button
      type="button"
      className={cn(
        "flex h-11 w-11 items-center justify-center rounded-full bg-[#f0f0f0] transition-colors",
        className,
        isDisabled ? " opacity-25" : "opacity-100 hover:bg-[#d8d8d8] active:bg-[#c0c0c0]",
      )}
      disabled={isDisabled}
      onClick={onPress}
    >
      <Image
        src="/icons/direction-left.svg"
        alt="left direction"
        width={11}
        height={16}
        className={cn(direction === ButtonDirection.right && "rotate-180")}
      />
    </button>
  );
}

const useButtonStyles = {
  primaryButton: {
    base: "primary-gradient",
    disabled: "primary-gradient-disabled",
  },
  secondaryButton: {
    base: "secondary-gradient border-2 border-solid border-primary",
    disabled: "!bg-none bg-white border-[#D8D8D8]",
  },
};

const useTextStyles = {
  primaryText: {
    base: "text-white",
    disabled: "text-[#828282]",
  },
  secondaryText: {
    base: "text-primary",
    disabled: "text-[#AFAFAF]",
  },
};
