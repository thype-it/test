import { cn } from "@/lib/utils";
import React from "react";

type Props = {
  children: React.ReactNode;
  className?: string;
  /**
   * Defaults to `true`
   */
  hasContainer?: boolean;
};

export default function Section({ children, className, hasContainer = true }: Props) {
  return (
    <section className={cn("flex w-full items-center overflow-hidden", className)}>
      {hasContainer ? (
        <div className="container h-full w-full overflow-hidden">{children}</div>
      ) : (
        children
      )}
    </section>
  );
}
