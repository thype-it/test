"use client";

import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import React from "react";

type Props = {
  isActive?: boolean;
  className?: string;
};

export default function DotsPagination({ isActive = false, className }: Props) {
  const variants = {
    active: {
      scale: [1.4, 1],
    },
    default: {
      scale: 1,
    },
  };

  return (
    <motion.svg
      height="10"
      width="10"
      variants={variants}
      animate={isActive ? "active" : "default"}
      transition={{ type: "spring" }}
      className={"my-2"}
    >
      <circle
        cx="5"
        cy="5"
        r="4"
        className={cn(isActive ? " fill-primary" : "fill-zinc-400", className)}
      />
    </motion.svg>
  );
}
