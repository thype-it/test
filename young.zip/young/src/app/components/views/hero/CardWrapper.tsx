import { cn } from "@/lib/utils";
import { MotionProps, motion } from "framer-motion";
import React from "react";

type Props = MotionProps & {
  children: React.ReactNode;
  className?: string;
};

export function CardWrapper({ children, className, ...rest }: Props) {
  return (
    <motion.div
      className={cn(" rounded-lg bg-primary bg-no-repeat p-4 text-white", className)}
      {...rest}
    >
      {children}
    </motion.div>
  );
}

type ContentProps = {
  title: string;
  text?: string;
  className?: string;
};

export function CardContent({ title, text, className }: ContentProps) {
  return (
    <div className={cn("flex flex-col", className)}>
      <h5 className="text-xl font-bold uppercase italic xl:text-3xl">{title}</h5>
      {text && <p className="text-sm uppercase italic xl:text-lg">{text}</p>}
    </div>
  );
}
