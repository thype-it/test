import { cn } from "@/lib/utils";
import { CardContent, CardWrapper } from "./CardWrapper";
import { type MotionValue, motion } from "framer-motion";

type Cards = "infinity" | "ticket" | "signal" | "refresher" | "percentage";

type CardPositionValues = {
  x?: MotionValue<number>;
  y?: MotionValue<number>;
};

type Props = {
  positionValues: {
    [key in Cards]: CardPositionValues;
  };
  opacity: MotionValue<number>;
  className?: string;
};

export default function Cards({ positionValues, opacity, className }: Props) {
  const { infinity, ticket, signal, refresher, percentage } = positionValues;
  return (
    <motion.div style={{ opacity }} className={cn("flex h-full w-full flex-col gap-2", className)}>
      <Card1 values={percentage} />
      <div className="flex h-2/3 w-full gap-2 ">
        <div className="flex basis-1/2 flex-col gap-2">
          <Card2 values={infinity} />
          <Card3 values={ticket} />
        </div>
        <div className="flex basis-1/2 flex-col gap-2">
          <Card4 values={refresher} />
          <Card5 values={signal} />
        </div>
      </div>
    </motion.div>
  );

  function Card1({ values }: { values: CardPositionValues }) {
    const { x, y } = values;
    return (
      <CardWrapper
        className="flex h-1/4 w-full bg-left"
        style={{ x, y, backgroundImage: 'url("/images/hero/icons/percentage.png")' }}
      >
        <CardContent
          text="podľa Teba"
          title="Nastav si program"
          className="justify-center pl-[22%]"
        />
      </CardWrapper>
    );
  }

  function Card2({ values }: { values: CardPositionValues }) {
    const { x, y } = values;

    return (
      <CardWrapper
        className="relative h-3/6 flex-grow bg-right-top"
        style={{ x, y, backgroundImage: 'url("/images/hero/icons/infinity.png")' }}
      >
        <CardContent title="Volaj zadarmo" text="s kamošmi v Telekome" />
      </CardWrapper>
    );
  }

  function Card3({ values }: { values: CardPositionValues }) {
    const { x, y } = values;

    return (
      <CardWrapper
        className="flex-grow bg-right-bottom"
        style={{
          x,
          y,
          backgroundImage: 'url("/images/hero/icons/ticket.png")',
          backgroundSize: "40%",
        }}
      >
        <CardContent text="na eventY" title="Vyhraj lístky" />
      </CardWrapper>
    );
  }

  function Card4({ values }: { values: CardPositionValues }) {
    const { x, y } = values;

    return (
      <CardWrapper
        className="flex-grow bg-right-bottom"
        style={{
          x,
          y,
          backgroundImage: 'url("/images/hero/icons/refresher.png")',
          backgroundSize: "40%",
        }}
      >
        <CardContent title="Refresher+" text="PRE NEkonečný SWIPE" />
      </CardWrapper>
    );
  }

  function Card5({ values }: { values: CardPositionValues }) {
    const { x, y } = values;

    return (
      <CardWrapper
        className="h-3/6 flex-grow bg-right-bottom"
        style={{ y, x, backgroundImage: 'url("/images/hero/icons/signal.png")' }}
      >
        <CardContent title="DÁTUJ zadarmo" text="vO Vybraných lokalitách" />
      </CardWrapper>
    );
  }
}
