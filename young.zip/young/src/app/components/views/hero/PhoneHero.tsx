import { motion, useMotionValueEvent, useTransform } from "framer-motion";
import Image from "next/image";
import { useState } from "react";
import type { HeroProps } from "./HeroSection";
import { cn } from "@/lib/utils";
import Cards from "./Cards";

//Animations order
const order = {
  start: 0,
  cardsStart: 0.2,
  phoneFinalWidth: 0.3,
  titleFinalWidth: 0.6,
  end: 0.8,
};

export default function PhoneHero({ scrollYProgress, className }: HeroProps) {
  useMotionValueEvent(scrollYProgress, "change", latest => {
    setProgress(widthInterval.get());
  });

  //Phone anim props
  const widthInterval = useTransform(
    scrollYProgress,
    [order.start, order.phoneFinalWidth],
    [133, 75],
  );
  const [progress, setProgress] = useState<number>(widthInterval.get());
  const phoneOpacity = useTransform(scrollYProgress, [0, 0.1], [0, 1]);

  //Swipe title anim props
  const scale = useTransform(
    scrollYProgress,
    [order.start, order.phoneFinalWidth, order.titleFinalWidth],
    [1, 0.65, 1.1],
  );

  //Cards anim props
  const x1 = useTransform(scrollYProgress, [order.cardsStart, order.titleFinalWidth], [-140, 0]);
  const x2 = useTransform(scrollYProgress, [order.cardsStart, order.titleFinalWidth], [-100, 0]);
  const x3 = useTransform(scrollYProgress, [order.cardsStart, order.titleFinalWidth], [300, 0]);
  const x4 = useTransform(scrollYProgress, [order.cardsStart, order.titleFinalWidth], [100, 0]);
  const y = useTransform(scrollYProgress, [order.cardsStart, order.titleFinalWidth], [150, 0]);
  const opacity = useTransform(scrollYProgress, [order.cardsStart, order.phoneFinalWidth], [0, 1]);

  return (
    <div className={cn("relative h-full w-full md:mx-auto md:w-3/4", className)}>
      <Phone />
      <div className="absolute bottom-4 left-0 flex h-4/6 min-h-112 w-full flex-col gap-2 px-4 ">
        <SwipeTitle />
        <Cards
          positionValues={{
            percentage: { x: x3 },
            infinity: { x: x1 },
            ticket: { x: x2 },
            signal: { y },
            refresher: { x: x4 },
          }}
          opacity={opacity}
        />
      </div>
    </div>
  );

  function Phone() {
    return (
      <motion.div
        className="absolute left-1/2 top-0 mx-auto h-lvh min-h-[540px] -translate-x-1/2"
        style={{ width: `${progress}%` }}
      >
        <div className="relative h-full w-full scale-101">
          <Image
            src="/images/hero/phone/Hero_background_375x662px.jpg"
            alt="Colorful swipe background"
            fill
            className="scale-99 object-cover"
            style={{
              maskImage: `url("/images/hero/Phone_black.png")`,
              maskRepeat: "no-repeat",
              maskSize: "100%",
              maskPosition: "center",
            }}
          />
          <motion.div style={{ opacity: phoneOpacity }}>
            <Image
              src="/images/hero/Phone.png"
              alt="Transparent phone frame"
              fill
              className="!top-1/2 !h-auto -translate-y-1/2 object-contain"
            />
          </motion.div>
        </div>
      </motion.div>
    );
  }

  function SwipeTitle() {
    return (
      <motion.div style={{ scale }} className="relative h-48 w-full">
        <Image
          src="/images/hero/phone/Hero_SWIPE_mobile-1023px.png"
          alt="Fancy title text for swipe"
          fill
          className="object-contain object-center-top-margin"
        />
      </motion.div>
    );
  }
}
