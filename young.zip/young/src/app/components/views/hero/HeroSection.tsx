"use client";

import { type MotionValue, useScroll, useSpring } from "framer-motion";
import { useRef } from "react";
import PhoneHero from "./PhoneHero";
import DesktopHero from "./DesktopHero";

export type HeroProps = {
  scrollYProgress: MotionValue<any>;
  className?: string;
};

export default function HeroSection() {
  const targetRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress: spring } = useScroll({
    target: targetRef,
    offset: ["start start", "end start"],
  });
  const physicsScrollX = { damping: 15, mass: 0.27, stiffness: 85 };
  const scrollYProgress = useSpring(spring, physicsScrollX);

  return (
    // upravit width section pre mobili dat max az do 1000px, potom desktop
    <section className="max relative h-3lvh w-full xl:max-h-hero-max-h  " ref={targetRef}>
      <div className="sticky left-0 top-0 h-1/3 w-full overflow-hidden">
        <PhoneHero scrollYProgress={scrollYProgress} className="xl:hidden" />
        <DesktopHero scrollYProgress={scrollYProgress} className="hidden xl:block" />
      </div>
    </section>
  );
}
