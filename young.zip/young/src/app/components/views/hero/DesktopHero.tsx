import React from "react";
import { motion, useTransform } from "framer-motion";
import Image from "next/image";
import Container from "../../shared/Container";
import type { HeroProps } from "./HeroSection";
import { cn } from "@/lib/utils";
import Cards from "./Cards";

//Animation order
const order = {
  start: 0.1,
  coverStart: 0.14,
  phoneFullWidth: 0.2,
  cardsStart: 0.35,
  coverFullWidth: 0.4,
  end: 0.5,
};

export default function DesktopHero({ scrollYProgress, className }: HeroProps) {
  //Cover animation
  const whiteBoxScale = useTransform(
    scrollYProgress,
    [order.coverStart, order.coverFullWidth],
    [0.4, 8],
  );
  const whiteBoxOpacity = useTransform(
    scrollYProgress,
    [0, order.coverStart, order.coverStart],
    [0, 0, 1],
  );

  //Phone animation
  const phoneScale = useTransform(scrollYProgress, [order.start, order.phoneFullWidth], [0.9, 1]);
  const phoneOpacity = useTransform(scrollYProgress, [order.start, order.coverStart], [0, 1]);

  //Title animation
  const titleScale = useTransform(scrollYProgress, [0, order.end], [1.5, 1.3]);

  //Cards animation
  const cardsOpacity = useTransform(scrollYProgress, [order.cardsStart, 0.45], [0, 1]);
  const y1 = useTransform(scrollYProgress, [order.cardsStart, order.end], [-200, 0]);
  const y2 = useTransform(scrollYProgress, [order.cardsStart, order.end], [100, 0]);
  const y3 = useTransform(scrollYProgress, [order.cardsStart, order.end], [250, 0]);
  const x1 = useTransform(scrollYProgress, [order.cardsStart, order.end], [100, 0]);
  const x2 = useTransform(scrollYProgress, [order.cardsStart, order.end], [250, 0]);

  //Hero BG animation

  const BGOpacity = useTransform(scrollYProgress, [order.phoneFullWidth, order.end], [1, 0]);

  return (
    <div className={cn("h-full w-full", className)}>
      <HeroBG />
      <Container className="absolute left-1/2 top-0 w-10/12 -translate-x-1/2 p-0 ">
        <div className="absolute left-0 top-0 flex h-full w-full items-center gap-20 py-8">
          <Phone />
          <Cards
            positionValues={{
              percentage: { y: y1 },
              infinity: { y: y2 },
              ticket: { y: y3 },
              signal: { x: x2 },
              refresher: { x: x1 },
            }}
            opacity={cardsOpacity}
            className=" max-h-[700px] justify-center"
          />
        </div>
      </Container>
    </div>
  );

  function HeroBG() {
    return (
      <motion.div className="relative h-4/5 w-full overflow-hidden" style={{ opacity: BGOpacity }}>
        <Image
          src="/images/hero/desktop/Hero_background_1366px.jpg"
          alt="Colorful swipe background"
          fill
          className="object-cover"
        />
      </motion.div>
    );
  }

  function Phone() {
    return (
      <div className="relative h-full basis-1/2">
        <motion.div
          style={{ opacity: phoneOpacity, scale: phoneScale }}
          className="h-full w-full origin-top"
        >
          <Image
            src="/images/hero/Phone_background.png"
            alt="Phone frame with colorful swipe background"
            fill
            className=" object-contain"
          />
          <WhiteBox />
        </motion.div>
        <motion.div
          className="absolute left-0 top-0 mx-auto h-full w-full "
          style={{ scale: titleScale }}
        >
          <Image
            src="/images/hero/desktop/Hero_SWIPE_desktop-1160px.png"
            alt="Title"
            fill
            className="object-contain object-center-top-margin"
          />
        </motion.div>
      </div>
    );
  }

  function WhiteBox() {
    return (
      <div className="absolute bottom-0 left-0 flex h-4/5 w-full justify-center">
        <motion.div
          className=" -z-10 h-full w-full origin-bottom rounded-3xl bg-white"
          style={{ scale: whiteBoxScale, opacity: whiteBoxOpacity }}
        />
      </div>
    );
  }
}
