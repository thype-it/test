import React, { ReactNode } from "react";
import HeadingMotion from "../../shared/HeadingMotion";
import Section from "../../shared/Section";
import { Carousel, CarouselContent, CarouselItem } from "../../shared/Carousel";

type Props = {
  children: ReactNode;
};

export default function CustomerPlanSection({ children }: Props) {
  return (
    <Section className="py-10 lg:pt-[7.5rem]">
      <HeadingMotion level={5} className="mb-8 lg:hidden">
        Alebo pozri, čo <br />
        sme ti vybrali
      </HeadingMotion>
      <h2
        className="hidden text-center font-teleneo text-[3.5rem] font-extrabold uppercase tracking-[0.7rem]
          text-primary md:text-[2.5rem] lg:block"
      >
        Alebo pozri, čo sme ti vybrali
      </h2>
      <div className="mx-auto mb-10">
        <Carousel
          opts={{
            breakpoints: {
              "min-width: (1024px)": { active: false },
            },
          }}
        >
          <CarouselContent className="-ml-4">{children}</CarouselContent>
        </Carousel>
      </div>
    </Section>
  );
}
