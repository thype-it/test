import Image from "next/image";
import { ReactNode } from "react";
import { CarouselItem } from "../../shared/Carousel";
import { cn } from "@/lib/utils";
import Button from "../../shared/Button";

type CarouselItemWrapperProps = {
  children: ReactNode;
};

type PlanItemHeaderProps = {
  headline: string;
  headlineColor?: string;
  isInverted?: boolean;
  isAlternativeColor?: boolean;
};

type Props = {
  backgroundSrc: string;
  price: number;
  children: ReactNode;
  textColor?: "black" | "white";
} & PlanItemHeaderProps;

export default function CustomerPlanItem({
  backgroundSrc,
  price,
  children,
  textColor,
  ...props
}: Props) {
  return (
    <CarouselItemWrapper>
      <div className="relative flex h-full min-h-[620px] w-full flex-col items-center justify-between rounded-2xl p-6">
        <div className="flex w-full flex-col items-center">
          <Image
            alt="item bg"
            src={backgroundSrc}
            fill
            priority
            className="h-full w-full rounded-2xl object-cover"
          />
          <PlanItemHeader {...props} />
        </div>
        <div className="z-10 flex h-full flex-col items-center justify-between">
          <ul className="flex w-full flex-col gap-4 pt-8">{children}</ul>
          <div className="flex w-full flex-col">
            <div className="mt-4 h-[1px] w-full bg-white opacity-40"></div>
            <div
              className={cn(
                "flex w-full justify-start pt-5",
                textColor === "black" ? "text-black" : "text-white",
              )}
            >
              <p className="font-teleneo text-rateplan-price">{price} €</p>
              <p className="pl-2 pt-[1.3rem] font-teleneo text-xs">/ 30 dní</p>
            </div>
            <Button fullWidth={true} isDisabled={true} className="mt-8">
              2. 5. 2024 spúšťame, stay tuned
            </Button>
          </div>
        </div>
      </div>
    </CarouselItemWrapper>
  );
}

function CarouselItemWrapper({ children }: CarouselItemWrapperProps) {
  return <CarouselItem className="m-0 basis-4/5 p-0 pl-4 lg:basis-1/3">{children}</CarouselItem>;
}

function PlanItemHeader({
  headline,
  headlineColor,
  isInverted = false,
  isAlternativeColor = false,
}: PlanItemHeaderProps) {
  return (
    <div className={cn("relative flex w-full flex-col items-center", isInverted && "pt-2")}>
      <Image
        alt="swipe logo"
        src={isAlternativeColor ? "/images/swipe-headline-white.png" : "/images/swipe-headline.png"}
        width={280}
        height={111}
        className={cn("relative z-20", isInverted && "order-2 mt-[-1rem]")}
      />
      <div
        className={cn(
          "relative z-10 flex h-full w-full justify-center",
          isInverted ? "order-1" : "mt-[-1rem]",
        )}
      >
        {isInverted ? (
          <Image
            alt="yellow stroke"
            src="/icons/slider-yellow-splash.svg"
            width={325}
            height={59}
            className="mt-[-0.4rem]"
          />
        ) : (
          <Image
            alt="yellow stroke"
            src="/icons/plan-item-short-stroke.svg"
            width={171.5}
            height={46.365}
          />
        )}
        <p
          className={cn(
            "absolute text-center font-teleneo text-[2.5rem]/[1.75rem] font-extrabold uppercase tracking-[0.5rem]",
            headlineColor ? `text-[${headlineColor}]` : "text-primary",
            isInverted ? "text-2xl" : "mt-[1rem]",
          )}
        >
          {headline}
        </p>
      </div>
    </div>
  );
}
