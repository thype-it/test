import { cn } from "@/lib/utils";
import Image from "next/image";
import { ReactNode } from "react";

type Props = {
  icon: string;
  children: ReactNode;
  textColor?: "black" | "white";
  secondaryPoint?: string;
};

export default function BulletPoint({
  icon,
  children,
  textColor = "white",
  secondaryPoint,
}: Props) {
  return (
    <li className="flex w-full flex-col gap-1">
      <div className="flex w-full items-center gap-5">
        <Image
          alt="point icon"
          src={icon}
          width={30}
          height={30}
          className={cn(textColor === "black" && "invert")}
        />
        <p
          className={cn(
            "font-teleneo text-[1.25rem]/[1.75rem] font-normal",
            textColor === "black" ? "text-black" : "text-white",
          )}
        >
          {children}
        </p>
      </div>
      {secondaryPoint && (
        <p
          className={cn(
            "pl-[3.125rem] font-teleneo text-sm opacity-80",
            textColor === "black" ? "text-black" : "text-white",
          )}
        >
          {secondaryPoint}
        </p>
      )}
    </li>
  );
}
