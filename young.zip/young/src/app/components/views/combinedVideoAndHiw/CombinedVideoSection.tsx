import { ReactNode } from "react";
import Section from "../../shared/Section";
import AppShowcase from "../appShowcase/AppShowcase";
import HowItWorks from "../howitworks/HowItWorks";
import { cn } from "@/lib/utils";
import Button, { ButtonVariant } from "../../shared/Button";
import Container from "../../shared/Container";

type Props = {
  children: ReactNode[];
};

export default function CombinedVideoSection({ children }: Props) {
  return (
    <>
      <Section hasContainer={false} className="hidden justify-center pt-28 lg:flex">
        <Container className="flex w-full items-stretch gap-9">
          <AppShowcase className="flex h-full w-full max-w-[425px] px-0" />
          <div className="flex w-full flex-col gap-9">
            <div className="flex flex-col items-center rounded-[0.9375rem] bg-[#F7F7F7] p-9">
              <p className="font-teleneo text-[2.5rem]/[2.5rem] font-extrabold uppercase tracking-[0.5rem] text-primary">
                swipe apPka
              </p>
              <p className="text-center font-teleneo text-base">
                Vyber si program alebo si vyskladaj podľa seba. Benefity, súťaže, prehľad spotreby,
                to všetko menežuješ v jednej appke. Tak naskoč.
              </p>
              <Button variant={ButtonVariant.secondary} isDisabled={true} className="mt-4">
                2. 5. 2024 spúšťame, stay tuned
              </Button>
            </div>
            <div
              className="flex h-full flex-col items-center justify-center rounded-[0.9375rem] border-[1px] border-solid
                border-primary px-9 pb-9"
            >
              <HowItWorks isDesktop={true} className="flex h-full flex-1 py-0 pt-12">
                {children}
              </HowItWorks>
            </div>
          </div>
        </Container>
      </Section>
      <MobileSection className="pt-[4.88rem] lg:hidden">{children}</MobileSection>
    </>
  );
}

type MobileSectionProps = {
  children: ReactNode[];
  className?: string;
};

function MobileSection({ children, className }: MobileSectionProps) {
  return (
    <Section hasContainer={false} className={cn("w-full flex-col items-center", className)}>
      <Container>
        <AppShowcase maxWidth={300} showButton={true} />
        <HowItWorks className="pb-0 pt-[5.5rem]">{children}</HowItWorks>
      </Container>
    </Section>
  );
}
