export default function Header() {
  return (
    <div className="rmenu-wrapper" data-menu-source="rmenu">
      &nbsp;
    </div>
  );
}
