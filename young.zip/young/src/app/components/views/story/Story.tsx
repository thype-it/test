import Image from "next/image";
import { cn } from "@/lib/utils";
import { Fragment, ReactNode } from "react";

type Props = Omit<Story, "id"> & { isVisible: boolean };

export default function Story({
  isVisible = false,
  imageSource,
  headline,
  imageHeadline,
  hollowHeadline,
  description,
  imageClassName,
}: Props) {
  return (
    <div
      className={cn(
        "dark-gradient pointer-events-none relative h-[31.875rem] w-full lg:h-[28.75rem] lg:rounded-[1rem]",
        isVisible ? "block" : "hidden",
      )}
    >
      <Image
        className={cn(
          "dark-gradient z-0 h-full w-full object-cover lg:rounded-[1rem]",
          imageClassName,
        )}
        alt="story image"
        src={imageSource}
        fill
        priority
        quality={100}
      />
      <div className="dark-gradient relative z-10 h-full w-full lg:rounded-[1rem]" />
      <div
        className={cn(
          `absolute left-0 top-[19.31rem] z-20 flex w-full flex-col justify-start px-4 lg:bottom-[5.56rem]
          lg:top-auto lg:px-11`,
        )}
      >
        {imageHeadline && (
          <Image
            alt="logo"
            src={imageHeadline.src}
            width={0}
            height={0}
            className={cn(imageHeadline.className)}
          />
        )}
        {headline &&
          headline.map(word => (
            <Headline key={word} isHollow={false}>
              {word}
            </Headline>
          ))}
        {hollowHeadline &&
          hollowHeadline.map(word => (
            <Headline key={word} isHollow={true}>
              {word}
            </Headline>
          ))}
        <p
          className={cn(
            "pt-1 font-teleneo text-story-description text-white lg:text-[1rem]/[1.25rem]",
            imageHeadline && "pt-4",
          )}
        >
          {description}
        </p>
      </div>
    </div>
  );
}

function Headline({ children, isHollow = false }: { children: ReactNode; isHollow: boolean }) {
  return (
    <p
      className={cn(
        "font-teleneo text-story-headline uppercase italic lg:text-[3.5rem]/[3.125rem]",
        isHollow && "hollow-text",
      )}
      style={{ color: isHollow ? "transparent" : "#FFF" }}
    >
      {children}
    </p>
  );
}
