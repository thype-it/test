"use client";

import { useEffect, useState, Fragment } from "react";
import Image from "next/image";
import { useInterval } from "react-use";
import StoryProgress from "./StoryProgress";
import { useMotionValue, motion } from "framer-motion";
import Story from "./Story";
import { ButtonDirection, DirectionButton } from "../../shared/Button";
import Section from "../../shared/Section";
import Container from "../../shared/Container";

type Props = {
  stories: Story[];
  headline: string;
  hasSecondarySplat?: boolean;
};

export default function Stories({ stories, headline, hasSecondarySplat = false }: Props) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const [delay, setDelay] = useState(7000);
  const [milliseconds, setMilliseconds] = useState(0);

  const progressValue = useMotionValue(0);

  const longAndShortPressNext = useLongAndShortPress(
    () => setPaused(true),
    handleNextIndex,
    () => setPaused(false),
    150,
  );
  const longAndShortPressPrev = useLongAndShortPress(
    () => setPaused(true),
    handlePrevIndex,
    () => setPaused(false),
    150,
  );

  useInterval(
    () => {
      handleNextIndex();
    },
    paused ? null : delay - milliseconds,
  );

  useInterval(
    () => {
      setMilliseconds(prevState => prevState + 4);
      progressValue.set(milliseconds);
    },
    paused ? null : 4,
  );

  return (
    <Section hasContainer={false} className="lg:px-4">
      <Container
        className="w-full px-0 sm:max-w-none md:max-w-none lg:max-w-[1024px] lg:px-[5.5rem] xl:max-w-[1280px]
          2xl:max-w-[1400px]"
      >
        <div className="hidden justify-between pb-4 lg:flex">
          <h2 className="text-[3.5rem]/[4rem] font-bold uppercase tracking-[0.7rem] text-primary lg:block">
            {headline}
          </h2>
          <div className="flex items-start gap-2 pt-[9px]">
            <DirectionButton onPress={handlePrevIndex} />
            <DirectionButton direction={ButtonDirection.right} onPress={handleNextIndex} />
          </div>
        </div>
        <div className="relative w-full" onContextMenu={e => e.preventDefault()}>
          <Blob isSecondaryDesktop={hasSecondarySplat} />
          <motion.div
            className="absolute z-20 w-full px-4 pt-5 lg:bottom-0 lg:px-11 lg:pb-[1.81rem] lg:pt-0"
            variants={{
              visible: { opacity: 1 },
              hidden: {
                opacity: 0,
                transition: {
                  duration: 0.1,
                  delay: 0.5,
                },
              },
            }}
            animate={paused ? "hidden" : "visible"}
          >
            <StoryProgress
              progressValue={progressValue}
              stories={stories.length}
              currentIndex={currentIndex}
              delay={delay}
            />
          </motion.div>
          <h3 className="absolute z-20 pl-4 pt-9 font-teleneo text-story-content-header uppercase text-white lg:hidden">
            {headline}
          </h3>
          {stories.map((story, index) => (
            <Story key={story.imageSource} isVisible={index === currentIndex} {...story} />
          ))}
          <div className="absolute bottom-0 flex h-full w-full lg:max-h-[calc(100%-80px)]">
            <button className="h-full w-[50%]" {...longAndShortPressPrev}></button>
            <button className="h-full w-[50%]" {...longAndShortPressNext}></button>
          </div>
        </div>
      </Container>
    </Section>
  );

  function handleNextIndex() {
    if (currentIndex === stories.length - 1) {
      setCurrentIndex(-1);
    }
    setCurrentIndex(prevIndex => prevIndex + 1);
    setMilliseconds(0);
  }

  function handlePrevIndex() {
    if (currentIndex === 0) {
      setCurrentIndex(stories.length);
    }
    setCurrentIndex(prevIndex => prevIndex - 1);
    setMilliseconds(0);
  }
}

type BlobProps = {
  isSecondaryDesktop?: boolean;
};

function Blob({ isSecondaryDesktop = false }: BlobProps) {
  return (
    <>
      <Image
        className="pointer-events-none absolute bottom-[3.82rem] left-0 z-20 h-[215px] w-[213px] lg:hidden"
        alt="story splat"
        src="/icons/story-splat.svg"
        width={213}
        height={215}
      />
      {isSecondaryDesktop ? (
        <Image
          className="pointer-events-none absolute bottom-[0rem] left-[-4rem] z-20 hidden h-[273px] w-[327px] lg:block"
          alt="story splat"
          src="/icons/story-big-splat-secondary.svg"
          width={0}
          height={0}
        />
      ) : (
        <Image
          className="pointer-events-none absolute bottom-[5.56rem] left-[-8rem] z-20 hidden h-[228px] w-[453px] lg:block"
          alt="story splat"
          src="/icons/story-big-splat.svg"
          width={453}
          height={228}
        />
      )}
    </>
  );
}

function useLongAndShortPress(
  longPressCallback: () => void,
  shortPressCallback: () => void,
  longPressEndCallback: (() => void) | null = null,
  ms = 200,
) {
  const [startLongPress, setStartLongPress] = useState(false);
  const [startShortPress, setStartShortPress] = useState(false);

  useEffect(() => {
    let timerId: string | number | NodeJS.Timeout | undefined;

    if (startLongPress) {
      timerId = setTimeout(() => {
        setStartShortPress(false);
        setStartLongPress(false);
        longPressCallback();
      }, ms);
    } else if (startShortPress) {
      setStartShortPress(false);
      shortPressCallback();

      clearTimeout(timerId);
    }

    return () => {
      clearTimeout(timerId);
    };
  }, [startLongPress, startShortPress]); // do not touch this, black magic

  return {
    onPointerDown: () => {
      setStartLongPress(true);
      setStartShortPress(true);
    },
    onMouseLeave: () => {
      setStartLongPress(false);
      longPressEndCallback ? longPressEndCallback() : null;
    },
    onTouchEnd: () => {
      setStartLongPress(false);
      longPressEndCallback ? longPressEndCallback() : null;
    },
    onMouseUp: () => {
      setStartLongPress(false);
      longPressEndCallback ? longPressEndCallback() : null;
    },
  };
}
