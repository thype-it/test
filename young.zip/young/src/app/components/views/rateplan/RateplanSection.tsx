"use client";

import { useState } from "react";
import RateplanSlider from "./RateplanSlider";
import Image from "next/image";
import Button from "../../shared/Button";
import Section from "../../shared/Section";
import HeadingMotion from "../../shared/HeadingMotion";
import Container from "../../shared/Container";

type Props = {
  rateplans: Rateplan[];
};

const speedMessages = [
  "Ideálna na chat a email",
  "Ideálna na hudbu a gaming",
  "Ideálna na videá a reels",
  "Maximálna rýchlosť - pripútaj sa!",
];

export default function RateplanSection({ rateplans }: Props) {
  const [voiceIndex, setVoiceIndex] = useState(1);
  const [dataIndex, setDataIndex] = useState(0);
  const [speedIndex, setSpeedIndex] = useState(0);
  const [isUsed, setIsUsed] = useState(false);

  const voiceData = getValuesForRateplan("voice", rateplans);
  const dataData = getValuesForRateplan("data", rateplans);
  const speedData = getValuesForRateplan("speed", rateplans);

  const selectedRateplan = rateplans.find(
    rateplan =>
      rateplan.voice === voiceData.at(voiceIndex) &&
      rateplan.data === dataData.at(dataIndex) &&
      rateplan.speed === speedData.at(speedIndex),
  );

  return (
    <Section hasContainer={false} className="flex w-full flex-col lg:px-4">
      <Container>
        <HeadingMotion level={2} className="pb-4 lg:hidden">
          Vyskladaj si program
        </HeadingMotion>
        <div className="flex w-full flex-col justify-center rounded-xl lg:justify-start">
          <div className="relative w-full rounded-xl">
            <RateplanBackground />
            <div className="relative z-10 flex h-full flex-col items-center justify-center pb-12 pt-9 lg:flex-row lg:p-9">
              <RateplanHeadline />
              <div className="flex w-full max-w-[25rem] flex-col items-center px-5 pt-[4.19rem] lg:p-0">
                <div className="slider-gradient flex w-full max-w-lg flex-col items-center gap-[1.49rem] rounded-lg p-5 pt-[1.59rem]">
                  <RateplanSlider
                    headline="Minúty a správy"
                    value={voiceIndex}
                    calculatedValue={voiceData.at(voiceIndex)}
                    length={voiceData.length - 1}
                    unit="voice"
                    handleChange={handleRateplanChange}
                    delay={0.2}
                    isUsed={isUsed}
                  />
                  <RateplanSlider
                    headline="Dáta"
                    value={dataIndex}
                    calculatedValue={dataData.at(dataIndex)}
                    length={dataData.length - 1}
                    unit="data"
                    handleChange={handleRateplanChange}
                    delay={1.2}
                    isUsed={isUsed}
                  />
                  <RateplanSlider
                    headline="Rýchlosť internetu"
                    value={speedIndex}
                    calculatedValue={speedData.at(speedIndex)}
                    length={speedData.length - 1}
                    unit="speed"
                    handleChange={handleRateplanChange}
                    isDisabled={dataIndex === 0}
                    delay={2.2}
                    isUsed={isUsed}
                  >
                    {dataIndex === 0
                      ? "Bez dát si nemôžeš vybrať rýchlosť internetu"
                      : speedMessages.at(speedIndex)}
                  </RateplanSlider>
                </div>
                <div className="flex w-full flex-col items-center justify-between pt-[0.88rem] lg:flex-row lg:pt-4">
                  {selectedRateplan && (
                    <div className="flex w-full justify-center lg:justify-start">
                      <p className="font-teleneo text-rateplan-price text-white">
                        {selectedRateplan.price / 100} €
                      </p>
                      <p className="pl-2 pt-[1.3rem] font-teleneo text-xs text-white">/ 30 dní</p>
                    </div>
                  )}
                  <Button isDisabled={true} className="mt-[1.37rem] lg:mt-0 lg:px-4">
                    2. 5. 2024 spúšťame, stay tuned
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </Section>
  );

  function handleRateplanChange(newValue: number, unit: "data" | "speed" | "voice") {
    if (unit === "voice") {
      if (newValue === 0 && dataIndex === 0) {
        return;
      }
      setVoiceIndex(newValue);
    }

    if (unit === "data") {
      if (newValue === 0 && voiceIndex === 0) {
        return;
      }
      setDataIndex(newValue);
    }

    if (unit === "speed") {
      setSpeedIndex(newValue);
    }

    setIsUsed(true);
  }

  function getValuesForRateplan(key: "speed" | "voice" | "data", rateplans: Rateplan[]) {
    const rateplansValues = getRateplanValues(key, rateplans) as number[];
    return sortRateplanValues(rateplansValues);
  }

  function sortRateplanValues(rateplanValues: number[]) {
    const sorted = rateplanValues.sort((a, b) => a - b);
    if (!sorted.includes(-1)) {
      return sorted;
    }

    sorted.shift();
    sorted.push(-1);
    return sorted;
  }

  function getRateplanValues(key: keyof Rateplan, rateplans: Rateplan[]) {
    return getUniqueValues<Rateplan>(key, rateplans);
  }

  function getUniqueValues<T extends {}>(key: keyof T, objects: T[]) {
    return Array.from(new Set(objects.map(item => item[key])));
  }
}

function RateplanHeadline() {
  return (
    <div className="flex w-full flex-col items-center">
      <h2
        className="hidden pb-[1.02rem] text-center font-teleneo text-[2.5rem] font-extrabold uppercase
          tracking-[0.7rem] text-white lg:block xl:text-[3.5rem]/[4rem]"
      >
        vyskladaj
        <br />
        si Program
      </h2>
      <Image
        alt="swipe"
        src="/images/slider-headline.png"
        width="482"
        height="160"
        className="z-20 h-20 w-[15.0625rem] lg:h-[8.5rem] lg:w-[24.5625rem]"
      />
      <Image
        alt="yellow splash"
        src="/icons/slider-yellow-splash.svg"
        width="331"
        height="55"
        className="absolute top-[6.28rem] w-[20.66469rem] lg:absolute lg:bottom-[3.5rem] lg:top-auto
          lg:rotate-[2.888deg] xl:bottom-[3.02rem] xl:h-[5.12519rem] xl:w-[33.24944rem]"
      />
      <p
        className="absolute top-[6.88rem] font-teleneo text-[2.125rem]/[2.75rem] font-extrabold uppercase
          tracking-[0.425rem] text-primary lg:relative lg:top-auto lg:tracking-[0.7rem] lg:text-[2.5]
          xl:text-[3.5rem]/[3.5rem]"
      >
        PODĽA TEBA
      </p>
    </div>
  );
}

function RateplanBackground() {
  return (
    <>
      <Image
        className="z-0 rounded-xl object-cover md:hidden"
        alt="slider background"
        src="/images/slider-bg-mobile.png"
        fill
        priority
      />
      <Image
        className="z-0 hidden rounded-xl object-cover md:block"
        alt="slider background"
        src="/images/slider-bg-desktop.png"
        fill
        priority
      />
    </>
  );
}
