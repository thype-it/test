import { Fragment, ReactNode, forwardRef } from "react";
import Image from "next/image";

import * as SliderPrimitive from "@radix-ui/react-slider";

import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

type Props = {
  length: number;
  calculatedValue: number | undefined;
  unit: "data" | "speed" | "voice";
  value: number;
  headline: string;
  handleChange: (newValue: number, unit: "data" | "speed" | "voice") => void;
  hasMarks?: boolean;
  isDisabled?: boolean;
  isUsed: boolean;
  delay?: number;
  children?: ReactNode;
};

export default function RateplanSlider({
  length,
  calculatedValue,
  unit,
  value,
  headline,
  handleChange,
  hasMarks,
  isDisabled = false,
  delay = 0,
  isUsed,
  children,
}: Props) {
  return (
    <div className="flex w-full flex-col items-center">
      <div className="flex w-full justify-between pb-4">
        <p
          className={cn(
            "font-teleneo text-[0.8125rem]/[1.125rem] font-bold lg:text-[1rem]/[1.47894rem]",
            isDisabled && "opacity-50",
          )}
        >
          {headline}
        </p>
        <p
          className={cn(
            "font-teleneo text-[0.8125rem]/[1.125rem] font-bold lg:text-[1rem]/[1.47894rem]",
            isDisabled && "opacity-50",
          )}
        >
          {unitFormat(calculatedValue, unit, isDisabled)}
        </p>
      </div>
      <div className="w-full">
        <Slider
          min={0}
          max={length}
          step={1}
          value={[value]}
          onValueChange={handleSliderChange}
          delay={delay}
          disabled={isDisabled}
          isUsed={isUsed}
        >
          {Array.from(Array(length + 1)).map((_, index) => (
            <SliderMark
              key={index}
              isActive={value > index && !isDisabled}
              position={
                index !== 0
                  ? index !== length
                    ? SliderMarkPosition.middle
                    : SliderMarkPosition.right
                  : SliderMarkPosition.left
              }
              className={cn(value === index && "invisible")}
            />
          ))}
        </Slider>
      </div>
      {children && (
        <div className="flex w-full justify-start pt-[0.8rem] lg:justify-end">
          <p
            className={cn(
              "font-teleneo text-xs text-black lg:text-[1rem]/[1.31463rem]",
              isDisabled && "opacity-50",
            )}
          >
            {children}
          </p>
        </div>
      )}
    </div>
  );

  function unitFormat(
    value: number | undefined,
    unit: "data" | "speed" | "voice",
    isDisabled?: boolean,
  ) {
    if (unit === "data") {
      if (value === -1) {
        return "Nekonečno dát";
      }
      return `${value ? value : "0"} GB`;
    }

    if (unit === "speed") {
      if (value === -1) {
        return "Nekonečná rýchlosť";
      }
      if (isDisabled) {
        return "Žiadna";
      }
      return `${value ? value : "0"} Mbps`;
    }

    if (unit === "voice") {
      if (value === -1) {
        return "Nekonečno minút a správ";
      }
      return value ? `${value}+${value}` : "0";
    }
  }

  function handleSliderChange(value: number[]) {
    if (value.length) {
      handleChange(value[0], unit);
    }
  }
}

enum SliderMarkPosition {
  left,
  middle,
  right,
}

type SliderMarkProps = {
  position: SliderMarkPosition;
  isActive: boolean;
  className?: string;
};

function SliderMark({ position, isActive, className }: SliderMarkProps) {
  return position === SliderMarkPosition.left || position === SliderMarkPosition.right ? (
    <svg
      width="22"
      height="16"
      viewBox="0 0 22 16"
      fill={isActive ? "#e30074" : "#d7cdd1"}
      xmlns="http://www.w3.org/2000/svg"
      className={cn(position === SliderMarkPosition.right && "rotate-180", className)}
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M19.824 10C17.4771 10 15.5543 11.7797 14.0019 13.5398C12.5359 15.2019 10.3904 16.2502 8 16.2502C3.58172 16.2502 0 12.6685 0 8.25024C0 3.83197 3.58172 0.250244 8 0.250244C10.2984 0.250244 12.3705 1.21951 13.8296 2.7716C15.354 4.39302 17.2086 6 19.434 6H20C21.1046 6 22 6.89543 22 8C22 9.10457 21.1046 10 20 10H19.824Z"
      />
    </svg>
  ) : (
    <svg
      width="28"
      height="16"
      viewBox="0 0 28 16"
      fill={isActive ? "#e30074" : "#d7cdd1"}
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M19.8296 2.7716C21.354 4.39302 23.2086 6 25.434 6H26C27.1046 6 28 6.89543 28 8C28 9.10457 27.1046 10 26 10H25.824C23.4771 10 21.5543 11.7797 20.0019 13.5398C18.5359 15.2019 16.3904 16.2502 14 16.2502C11.6096 16.2502 9.46408 15.2019 7.99815 13.5398C6.44572 11.7797 4.52289 10 2.17597 10H2C0.895431 10 0 9.10457 0 8C0 6.89543 0.895431 6 2 6H2.56595C4.79144 6 6.64596 4.39302 8.17035 2.7716C9.62955 1.21951 11.7016 0.250244 14 0.250244C16.2984 0.250244 18.3705 1.21951 19.8296 2.7716Z"
      />
    </svg>
  );
}

type SliderMotionCircleProps = {
  radius: string;
  delay: number;
};

function SliderMotionCircle({ radius, delay }: SliderMotionCircleProps) {
  return (
    <motion.circle
      cx="29"
      cy="29"
      r={radius}
      fill="none"
      stroke="#e20074"
      strokeWidth={3}
      strokeOpacity={0.6}
      variants={{
        hidden: { opacity: 0 },
        show: { opacity: [0, 1, 0], transition: { repeat: Infinity, repeatDelay: 2.4 } },
      }}
    />
  );
}

const Slider = forwardRef<
  React.ElementRef<typeof SliderPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof SliderPrimitive.Root> & { delay?: number; isUsed?: boolean }
>(({ className, children, delay = 0, isUsed = false, ...props }, ref) => (
  <SliderPrimitive.Root
    ref={ref}
    className={cn(
      "relative flex h-[1.125rem] w-full touch-none select-none items-center",
      !props.disabled && "cursor-pointer",
      className,
    )}
    {...props}
  >
    <div className="absolute flex w-full items-center justify-between">{children}</div>
    <SliderPrimitive.Track className="relative h-1 w-full grow overflow-hidden rounded-full bg-[#d7cdd1]">
      <SliderPrimitive.Range
        className={cn("absolute h-full bg-[#E30074]", props.disabled && "bg-[#d7cdd1]")}
      />
    </SliderPrimitive.Track>
    <SliderPrimitive.Thumb
      className={cn(
        `relative flex h-7 w-7 items-center justify-center rounded-full border-[0.24rem] border-white
        bg-[#E30074] ring-offset-white focus-visible:outline-none disabled:pointer-events-none
        disabled:opacity-50`,
        props.disabled && "bg-[#d7cdd1]",
      )}
    >
      <motion.svg
        width="58"
        height="58"
        viewBox="0 0 58 58"
        className="absolute"
        variants={{
          hidden: { opacity: 0 },
          show: {
            opacity: 1,
            transition: {
              staggerChildren: 0.2,
              delayChildren: delay,
              duration: 0.2,
            },
          },
        }}
        initial="hidden"
        animate={!isUsed && !props.disabled ? "show" : "hidden"}
      >
        {Array.from(Array(3)).map((_, index) => (
          <SliderMotionCircle key={index} radius={String(17.5 + index * 5)} delay={delay} />
        ))}
      </motion.svg>
      <Image alt="thumb-icon" width={13} height={13} src="/icons/slider-thumb-icon.svg" />
    </SliderPrimitive.Thumb>
  </SliderPrimitive.Root>
));

Slider.displayName = SliderPrimitive.Root.displayName;
