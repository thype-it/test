import Button from "../../shared/Button";
import Section from "../../shared/Section";
import Image from "next/image";

export default function Footer() {
  return (
    <Section hasContainer={false} className="w-full pt-32 lg:pt-40">
      <div className="relative flex w-full flex-col">
        <FooterStroke />
        <div
          className="flex w-full flex-col items-center bg-[#262626] pb-12 pt-[3rem] lg:flex-row lg:justify-between
            lg:pb-20"
        >
          <div className="flex w-full flex-col items-center justify-center lg:flex-row lg:gap-7">
            <p
              className="text-center font-teleneo text-[1.75rem]/[normal] font-extrabold uppercase tracking-[0.35rem]
                text-white"
            >
              SLEDUJ SWIPE
            </p>
            <div className="flex justify-center gap-3 pt-2 lg:flex-row lg:pt-0">
              <Image alt="tiktok logo" src="/images/tiktok.png" width={43} height={43} />
              <Image alt="tiktok logo" src="/images/youtube.png" width={43} height={43} />
              <Image alt="tiktok logo" src="/images/instagram.png" width={43} height={43} />
            </div>
          </div>
          <div className="flex w-full flex-col items-center justify-center pt-12 lg:flex-row lg:gap-5 lg:pt-0">
            <p className="font-teleneo text-sm text-white">
              Aby si mohol swipovať, potrebuješ appku 👇
            </p>
            <Button isDisabled={true} className="mt-[0.8rem] lg:mt-0">
              2. 5. 2024 spúšťame, stay tuned
            </Button>
          </div>
        </div>
      </div>
    </Section>
  );
}

function FooterStroke() {
  return (
    <>
      <div className="absolute top-[-5.5rem] h-40 w-full lg:hidden">
        <Image
          alt="mobile stroke"
          src="/icons/footer-mobile.svg"
          width={400}
          height={276}
          className="h-40 w-full"
        />
      </div>
      <div className="absolute top-[-7rem] hidden h-40 w-full lg:block">
        <Image
          alt="mobile stroke"
          src="/icons/footer-desktop.svg"
          width={1700}
          height={200}
          className="h-40 w-full"
        />
      </div>
    </>
  );
}
