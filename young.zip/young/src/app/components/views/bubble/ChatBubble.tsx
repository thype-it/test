"use client";

import Image from "next/image";

export default function ChatBubble() {
  return (
    <div className="pointer-events-none fixed z-30 h-full w-full">
      <Image
        //@ts-ignore: workaround for chat script
        onClick={() => bubble.toggle()}
        alt="chat bubble"
        src="/images/chat-bubble.png"
        width={73}
        height={99}
        className="pointer-events-auto absolute bottom-0 right-0 z-30 cursor-pointer"
      />
    </div>
  );
}
