"use client";

import { cn } from "@/lib/utils";
import HeadingMotion from "../../shared/HeadingMotion";
import Section from "../../shared/Section";
import { motion } from "framer-motion";
import Image from "next/image";
import { ReactNode, useRef } from "react";

type Props = {};

const slides = [
  { icon: <Logo src="/icons/matove-akcie.svg" className="lg:h-[9.1875rem] lg:w-[9.1875rem]" /> },
  { icon: <Logo src="/icons/slovnaft.svg" className="lg:h-[9.1875rem] lg:w-[9.1875rem]" /> },
  { icon: <Logo src="/icons/planeo.svg" className="lg:h-[9.1875rem] lg:w-[9.1875rem]" /> },
  {
    icon: <Logo src="/icons/telekom-predajne.svg" className="lg:h-[9.1875rem] lg:w-[9.1875rem]" />,
  },
];

export default function Partners() {
  const duplicatedSlides = [...slides, ...slides];

  return (
    <Section
      hasContainer={false}
      className="lg: flex w-full flex-col items-center py-10 lg:py-0 lg:pt-[7.5rem]"
    >
      <HeadingMotion level={2} className="lg:hidden">
        SWIPE simku si
        <br />
        kúpiš aj TU
      </HeadingMotion>
      <h2
        className="hidden w-full text-center font-teleneo text-[2.5rem]/[2.5rem] font-extrabold uppercase
          tracking-[0.5rem] text-primary lg:block"
      >
        SWIPE simku si kúpiš aj TU
      </h2>
      <div className="flex flex-col items-center">
        <p className="text-center font-teleneo text-base/[1.25rem] lg:pt-3">
          Ale ak ti môžeme poradiť, skús dať
          <br className="lg:hidden" /> prednosť eSIM. Budeš viac EKO a do
          <br className="lg:hidden" /> pár minút ready to go!
        </p>
        <div className="relative w-full">
          <motion.div
            className="flex lg:hidden"
            animate={{
              x: ["-100%", "0%"],
              transition: {
                ease: "linear",
                duration: 20,
                repeat: Infinity,
              },
            }}
          >
            {duplicatedSlides.map((slide, index) => (
              <div
                key={index}
                className="flex-shrink-0"
                style={{ width: `${100 / slides.length}%` }}
              >
                <div className="flex h-full flex-col items-center justify-center text-6xl">
                  {slide.icon}
                </div>
              </div>
            ))}
          </motion.div>
          <div className="hidden gap-8 pt-2 lg:flex">{slides.map(slide => slide.icon)}</div>
        </div>
      </div>
    </Section>
  );
}

type LogoProps = {
  src: string;
  className?: string;
};

export function Logo({ src, className }: LogoProps) {
  return (
    <Image
      alt="partner logo"
      src={src}
      width={0}
      height={0}
      className={cn("h-[6.125rem] w-[6.125rem]", className)}
    />
  );
}
