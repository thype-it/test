"use client";

import { ReactNode, useCallback, useState } from "react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "../../shared/Carousel";
import Section from "../../shared/Section";
import { type UseEmblaCarouselType } from "embla-carousel-react";
import { AnimatePresence, motion } from "framer-motion";
import DotsPagination from "../../shared/DotsPagination";
import Button, { ButtonVariant } from "../../shared/Button";
import { cn } from "@/lib/utils";
import HeadingMotion from "../../shared/HeadingMotion";

const variants = {
  enter: (direction: number) => {
    return {
      x: direction > 0 ? 1000 : -1000,
      opacity: 0,
    };
  },
  center: {
    zIndex: 1,
    x: 0,
    opacity: 1,
  },
  exit: (direction: number) => {
    return {
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0,
    };
  },
};

type CarouselApi = UseEmblaCarouselType[1];
type HowItWorksProps = {
  children: ReactNode[];
  isDesktop?: boolean;
  className?: string;
};

export default function HowItWorks({ children, isDesktop = false, className }: HowItWorksProps) {
  const [[page, direction], setPage] = useState([0, 0]);

  const handleChangeScroll = useCallback((api: CarouselApi) => {
    if (api) {
      setPage([api.selectedScrollSnap(), api.selectedScrollSnap() - api.previousScrollSnap()]);
    }
  }, []);

  return (
    <Section className={cn("py-10", className)} hasContainer={false}>
      <div className="relative px-4">
        <h3
          className="relative z-20 hidden text-center font-teleneo text-[2.5rem]/[2.75rem] font-extrabold uppercase
            tracking-[0.35rem] text-primary lg:block"
        >
          Ako to <br />
          funguje?
        </h3>
        <HeadingMotion level={3} className="relative z-20 lg:hidden">
          Ako to <br />
          funguje?
        </HeadingMotion>
        <Carousel handleSelect={handleChangeScroll} className="relative z-20 pb-5 pt-3">
          <CarouselContent className="-ml-4">{children}</CarouselContent>
          {isDesktop && (
            <div className="relative z-20 flex justify-center gap-1 pt-5">
              <CarouselPrevious />
              <CarouselNext />
            </div>
          )}
        </Carousel>
        {children && !isDesktop && (
          <div className="relative z-20 flex justify-center gap-1">
            {Array.from(Array(children.length)).map((_, index) => (
              <DotsPagination key={index} isActive={index === page ? true : false} />
            ))}
          </div>
        )}
        <div className="flex flex-col items-center gap-3 pt-7">
          <p className="font-teleneo text-xl font-bold text-black">Niečo ešte nejasné?</p>
          <Button variant={ButtonVariant.secondary}>Prejsť na najčastejšie otázky</Button>
        </div>
        <AnimatePresence initial={false} custom={direction}>
          <motion.img
            key={page}
            src={`/icons/howitworks-${page + 1}.svg`}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 300, damping: 30 },
              opacity: { type: "spring", duration: 0.2 },
            }}
            className="pointer-events-none absolute bottom-0 left-[-12rem] right-0 top-[-2.5rem] mx-auto h-[15rem]"
          />
        </AnimatePresence>
      </div>
    </Section>
  );
}

type StepProps = {
  children: ReactNode;
};

export function Step({ children }: StepProps) {
  return (
    <CarouselItem className="m-0 basis-full p-0 pl-4">
      <div className="flex w-full items-center justify-center">
        <p className="text-center font-teleneo text-base/[1.25rem] text-black">{children}</p>
      </div>
    </CarouselItem>
  );
}
