import Button, { ButtonVariant } from "../../shared/Button";
import Section from "../../shared/Section";
import { cn } from "@/lib/utils";

type Props = {
  className?: string;
  showButton?: boolean;
  maxWidth?: number;
};

export default function AppShowcase({ className, showButton, maxWidth }: Props) {
  return (
    <Section hasContainer={false} className={cn("flex w-full justify-center px-4", className)}>
      <div
        className={cn(
          "flex w-full flex-col items-center rounded-[3.4rem] lg:rounded-[3.6rem]",
          maxWidth && `max-w-[${maxWidth}px]`,
        )}
      >
        <video
          src="/videos/swipe-animation.mp4"
          width={maxWidth}
          autoPlay
          loop
          muted
          playsInline
          className="rounded-[3.4rem] lg:rounded-[3.6rem]"
        ></video>
        {showButton && (
          <Button variant={ButtonVariant.secondary} isDisabled={true} className="mt-10">
            2. 5. 2024 spúšťame, stay tuned
          </Button>
        )}
      </div>
    </Section>
  );
}
