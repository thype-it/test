import { cn } from "@/lib/utils";
import Image from "next/image";

export type TicketProps = {
  headline: string;
  points: string[];
  ticketWinnings: {
    amount: string;
    type: string;
  }[];
  className?: string;
} & TicketHeaderProps;

export default function Ticket({
  headline,
  points,
  ticketWinnings,
  className,
  ...props
}: TicketProps) {
  return (
    <div
      className={cn(
        "ticket-shadow h-[400px] w-full rounded-lg rounded-tl-lg rounded-tr-lg bg-white",
        className,
      )}
    >
      <div
        className="flex w-full flex-col items-center rounded-tl-lg rounded-tr-lg border-b-[1px] border-dashed
          border-[#e1e1e1] bg-white"
      >
        <TicketHeader {...props} />
        <div className="flex w-full flex-col px-5 pb-4 pt-3">
          <p className="font-teleneo text-[1.3125rem]/[normal] font-extrabold">{headline}</p>
          <ul className="list-inside list-[square] pl-[10px] pt-[0.37rem]">
            {points.map(point => (
              <li key={point} className="font-teleneo text-base text-black">
                {point}
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="flex w-full flex-col items-center px-5 pt-[0.44rem]">
        {ticketWinnings.map(winning => (
          <div key={winning.type} className="flex w-full items-center">
            <div className="w-24">
              <p className="font-teleneo text-[2.5rem]/[normal] font-extrabold text-primary">
                {winning.amount}
              </p>
            </div>
            <div className="w-full">
              <p className="w-full font-teleneo text-base">{winning.type}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export type TicketHeaderProps = {
  imageSrc: string;
  textureSrc: string;
  ticketType: string;
  isPreparing?: boolean;
};

function TicketHeader({ imageSrc, textureSrc, ticketType, isPreparing }: TicketHeaderProps) {
  return (
    <div className="relative flex h-[6.9375rem] w-full rounded-tl-lg rounded-tr-lg">
      <div className="h-full w-[70%] rounded-bl-[0.8125rem] rounded-br-[0.8125rem] rounded-tl-lg rounded-tr-lg">
        <Image
          alt="ticket image"
          src={imageSrc}
          width={189}
          height={111}
          className="h-full w-full rounded-bl-[0.8125rem] rounded-tl-lg object-cover"
        />
      </div>
      <div className="relative h-full w-[30%] rounded-br-[0.8125rem] rounded-tr-lg">
        <Image
          alt="ticket image"
          src={textureSrc}
          width={89}
          height={111}
          className="h-full w-full rounded-br-[0.8125rem] rounded-tr-lg object-cover"
        />
        <div className="absolute top-0 h-full w-full border-l-2 border-dashed border-black" />
      </div>
      <div className="absolute top-0 flex h-full w-full flex-col items-end justify-center pr-[0.85rem]">
        <p className="font-teleneo text-xl/[normal] font-extrabold text-white">{ticketType}</p>
        <p className="hollow-text font-teleneo text-[3rem]/[normal] font-extrabold text-transparent">
          TICKET
        </p>
      </div>
      {isPreparing && (
        <div className="absolute left-1 top-1 z-20 flex gap-1 rounded-[0.375rem] bg-black px-2 py-1 opacity-70">
          <Image
            alt="Waiting icon"
            src="/icons/waiting.svg"
            width={12}
            height={12}
            className="opacity-100"
          />
          <p className="font-teleneo text-xs/[0.75rem] uppercase text-[#F4F5F6]">PRIPRAVUJEME</p>
        </div>
      )}
    </div>
  );
}
