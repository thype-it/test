"use client";

import React, { Dispatch, SetStateAction, useEffect, useRef, useState } from "react";
import { AnimatePresence, delay, motion, useMotionValue, useTransform } from "framer-motion";
import Section from "../../shared/Section";
import Container from "../../shared/Container";
import { cn } from "@/lib/utils";
import HeadingMotion from "../../shared/HeadingMotion";
import Button from "../../shared/Button";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "../../shared/Carousel";
import { wrap } from "popmotion";
import DotsPagination from "../../shared/DotsPagination";
import Ticket, { TicketProps } from "./Ticket";

//change items props and item data according to the UI
type ItemProps = TicketProps;

type Props = {
  items: ItemProps[];
};

export default function TestTicketSection({ items }: Props) {
  const [itemGroup, setItemGroup] = useState(items);
  const handleItems = (items: ItemProps[]) => {
    setItemGroup(items);
  };

  return (
    <Section className="relative pb-20 pt-10 lg:pb-0" hasContainer={false}>
      <Container className="relative px-10 md:h-[500px] md:p-0">
        <div
          className="relative z-10 flex flex-col items-center bg-white md:h-[500px] md:w-[400px] md:items-start
            md:pl-[5.5rem] md:pr-8"
        >
          <HeadingMotion className="mt-8 md:text-left">
            Tickety <br /> na podujatia
          </HeadingMotion>
          <p className="my-3">
            S programom SWIPE môžeš v appke súťažiť o nadupané eventy a vyhrať vstupenky pre seba a
            svojich kamošov. Žrebujeme každý mesiac!
          </p>
          <MobileCarousel items={itemGroup} setItems={handleItems} />
          <Button className="mt-5 md:mt-0" isDisabled={true}>
            2. 5. 2024 spúšťame, stay tuned
          </Button>
        </div>
        <DesktopCarousel items={itemGroup} setItems={handleItems} />
        <div className="absolute left-0 top-0 hidden h-full w-full -translate-x-full bg-white md:block" />
      </Container>
    </Section>
  );
}

type CarouselProps = {
  items: ItemProps[];
  setItems: (items: ItemProps[]) => void;
};

function MobileCarousel({ items }: CarouselProps) {
  const [itemGroup, setItemGroup] = useState(items);
  const [page, setPage] = useState(0);
  const wrapeItemIndex = wrap(0, items.length, page);
  const swipeConfidenceThreshold = 10000;
  const currentItemIndex = items.findIndex(item => item === itemGroup[0]);

  return (
    <div className="flex w-full flex-col items-center">
      <div className="relative my-4 h-[400px] w-full max-w-[400px] md:hidden">
        <AnimatePresence initial={false}>
          <motion.div
            drag="x"
            key={page}
            dragConstraints={{ left: 0, right: 0 }}
            transition={{
              x: { type: "spring" },
              opacity: { type: "spring", duration: 0.4 },
              scale: { type: "spring", duration: 1.5 },
            }}
            whileDrag={{ scale: 0.94, opacity: 0.9, transition: { type: "spring", duration: 0.2 } }}
            dragElastic={1}
            className="absolute left-0 top-0 h-full w-full"
            onDragEnd={(e, { offset, velocity }) => {
              const swipe = getSwipePower(offset.x, velocity.x);
              if (swipe < -swipeConfidenceThreshold) {
                paginate();
              }
            }}
            initial={{ x: 10, opacity: 1 }}
            animate={{ x: 0, opacity: 1, zIndex: 20 }}
            exit={{ x: -600, scale: 0.65, opacity: 0.7, zIndex: 30 }}
          >
            <Ticket {...items[wrapeItemIndex]} />
          </motion.div>
        </AnimatePresence>
        <AnimatePresence>
          <motion.div
            initial={{ x: 10, opacity: 1 }}
            animate={{ x: 0, opacity: 1 }}
            className="absolute left-0 top-0 h-full w-full"
            key={page}
            transition={{
              x: { type: "spring", duration: 2 },
              opacity: { duration: 0.4 },
            }}
          >
            {itemGroup.slice(1).map((item, i) => {
              const isLast = items.length - 2 === i;
              return (
                <motion.div
                  key={item.headline + Math.random() * Math.random() * 1000}
                  initial={isLast && { opacity: 0, x: 60, scale: 0.65 }}
                  animate={isLast && { opacity: 1, x: 0, scale: 1 }}
                  transition={{ opacity: { duration: 0.3 }, x: { duration: 0.7 } }}
                  className="absolute top-0 h-full w-full"
                  style={{ zIndex: items.length - i, left: 10 * (i + 1) }}
                >
                  <Ticket {...item} />
                </motion.div>
              );
            })}
          </motion.div>
        </AnimatePresence>
      </div>
      <div className="flex gap-1">
        {items.map((item, i) => {
          return (
            <DotsPagination
              key={item.imageSrc + Math.random() * Math.random() * 1000}
              isActive={i === currentItemIndex ? true : false}
              className={"md:hidden"}
            />
          );
        })}
      </div>
    </div>
  );

  function paginate() {
    setPage(page + 1);
    setItemGroup([...itemGroup.slice(1), itemGroup[0]]);
  }
  function getSwipePower(offset: number, velocity: number) {
    return Math.abs(offset) * velocity;
  }
}

function DesktopCarousel({ items }: CarouselProps) {
  return (
    <Carousel
      className="absolute bottom-0 top-0 my-auto mb-10 hidden w-[300px] md:left-[400px] md:block"
      overflow="unset"
    >
      <CarouselContent className="-ml-4">
        {items.map(item => (
          <CarouselItem
            key={item.textureSrc + Math.random() * Math.random() * 1000}
            className="m-0 basis-full p-0 pl-4"
          >
            <Ticket {...item} className="h-[400px]" />
          </CarouselItem>
        ))}
      </CarouselContent>
      <div className="mt-4 flex gap-1">
        <CarouselPrevious />
        <CarouselNext />
      </div>
    </Carousel>
  );
}
