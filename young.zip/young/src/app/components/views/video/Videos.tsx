"use client";

import { cn } from "@/lib/utils";
import { YouTubeEmbed } from "@next/third-parties/google";
import { Fragment, ReactNode, useState } from "react";
import { useMedia } from "react-use";
import Section from "../../shared/Section";
import Container from "../../shared/Container";
import HeadingMotion from "../../shared/HeadingMotion";

type Props = {
  videos: Video[];
};

export default function Videos({ videos }: Props) {
  const [currentVideo, setCurrentVideo] = useState(videos.at(0));
  const isWide = useMedia("(min-width: 640px)", false);

  return (
    <Section hasContainer={false} className="px-0 pt-[5.5rem] lg:pt-[10rem]">
      <Container className="flex w-full flex-col items-center justify-center px-0 lg:flex-row lg:items-start lg:px-[5.5rem]">
        <HeadingMotion level={2} className="lg:hidden">
          Videjká
        </HeadingMotion>
        {currentVideo && (
          <div className="lg h-full w-full pb-3 pt-3 lg:order-2 lg:pb-0 lg:pt-0">
            <YouTubeEmbed
              videoid={currentVideo.youtubeId}
              style={`${isWide ? "border-radius: 0.5rem" : ""}; max-width: none;`}
            />
          </div>
        )}
        <div className="flex h-full w-full flex-col gap-2 px-4 lg:order-1 lg:max-w-[25rem] lg:pl-0 lg:pt-4">
          <h2
            className="hidden w-full text-start font-teleneo text-[2.5rem]/[2.5rem] font-extrabold uppercase
              tracking-[0.5rem] text-primary lg:block"
          >
            Ďalšie návody
          </h2>
          {videos.map(
            video =>
              currentVideo && (
                <VideoButton
                  key={video.youtubeId}
                  isActive={video.videoHeadline === currentVideo.videoHeadline}
                  onClick={() => setCurrentVideo(video)}
                >
                  {video.videoHeadline}
                </VideoButton>
              ),
          )}
        </div>
      </Container>
    </Section>
  );
}

type VideoButtonProps = {
  isActive: boolean;
  children: ReactNode;
  onClick?: () => void;
  isDisabled?: boolean;
};

function VideoButton({ isActive, children, onClick, isDisabled = false }: VideoButtonProps) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "rounded-lg border-[1px] border-solid border-[#E3E3E3] p-4 transition-all",
        isActive && "border-[#e20074]",
      )}
    >
      <div className="flex justify-between">
        <p
          className={cn(
            "font-base/[normal] text-ellipsis font-teleneo font-normal transition-all",
            isActive && "font-bold text-[#e20074]",
          )}
        >
          {children}
        </p>
        <PlayIcon className={cn("fill-black transition-all", isActive && "fill-[#e20074]")} />
      </div>
    </button>
  );
}

type PlayIconProps = {
  className?: string;
};

function PlayIcon({ className }: PlayIconProps) {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <g id="play_arrow_FILL1_wght400_GRAD0_opsz24">
        <path id="Vector" d="M8 19V5L19 12L8 19Z" />
      </g>
    </svg>
  );
}
