import { Accordion } from "@/app/components/views/faq/accordion";
import { ReactNode } from "react";
import Button, { ButtonVariant } from "../../shared/Button";
import Section from "../../shared/Section";
import HeadingMotion from "../../shared/HeadingMotion";

type Props = {
  children: ReactNode;
};

export default function FaqSection({ children }: Props) {
  return (
    <Section hasContainer={false} className="w-full px-4 lg:pt-[6.75rem]">
      <div className="flex w-full flex-col items-center">
        <HeadingMotion level={2} className="pb-4 lg:hidden">
          Najčastejšie
          <br />
          otázky
        </HeadingMotion>
        <h2
          className="hidden text-center font-teleneo text-[3.5rem] font-extrabold uppercase tracking-[0.7rem]
            text-primary lg:block"
        >
          najčastejšie otázky
        </h2>
        <div className="flex w-full max-w-[41rem] flex-col items-center">
          <Accordion type="single" collapsible className="flex w-full flex-col gap-2 ">
            {children}
          </Accordion>
          <div className="flex w-full flex-col items-center pt-7">
            <p className="font-base/[1rem] text-center font-teleneo font-bold tracking-[0.01rem]">
              Ak si nenašiel odpoveď, spýtaj sa nášho chatbota 🤖{" "}
            </p>
            <Button
              isDisabled={true}
              variant={ButtonVariant.secondary}
              fullWidth={true}
              className="mt-3"
            >
              2. 5. 2024 môžeš pokecať s chatbotom
            </Button>
          </div>
        </div>
      </div>
    </Section>
  );
}
