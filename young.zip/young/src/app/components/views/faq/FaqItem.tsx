import { ReactNode } from "react";
import {
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/app/components/views/faq/accordion";

type Props = {
  index: number;
  question: string;
  children: ReactNode;
};

export default function FaqItem({ index, question, children }: Props) {
  return (
    <>
      <AccordionItem value={`item-${index}`}>
        <AccordionTrigger>{question}</AccordionTrigger>
        <AccordionContent className="pb-0 pt-5">{children}</AccordionContent>
      </AccordionItem>
    </>
  );
}
