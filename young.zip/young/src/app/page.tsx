import HeroSection from "@/app/components/views/hero/HeroSection";
import RateplanSection from "@/app/components/views/rateplan/RateplanSection";
import Stories from "@/app/components/views/story/Stories";
import { getRateplanData } from "@/services/young-api";
import CustomerPlanSection from "./components/views/customerPlan/CustomerPlanSection";
import TicketSection from "./components/views/tickets/TicketSection";
import Videos from "./components/views/video/Videos";
import FaqSection from "./components/views/faq/FaqSection";
import FaqItem from "./components/views/faq/FaqItem";
import HowItWorks, { Step } from "./components/views/howitworks/HowItWorks";
import Partners, { Logo } from "./components/views/partners/Partners";
import CustomerPlanItem from "./components/views/customerPlan/CustomerPlanItem";
import BulletPoint from "./components/views/customerPlan/BulletPoint";
import ChatBubble from "./components/views/bubble/ChatBubble";
import CombinedVideoSection from "./components/views/combinedVideoAndHiw/CombinedVideoSection";
import Footer from "./components/views/footer/Footer";

export default async function Home() {
  const rateplans = await getRateplanData();

  return (
    <main className="relative flex min-h-screen w-full flex-col items-center">
      <HeroSection />
      <RateplanSection rateplans={rateplans} />

      <CustomerPlanSection>
        <CustomerPlanItem
          backgroundSrc="/images/plan-item-magenta.png"
          isAlternativeColor={true}
          isInverted={true}
          headline="nekonečný"
          price={22}
        >
          <BulletPoint icon="/icons/refresher.svg">Refresher+ predplatné zadarmo</BulletPoint>
          <BulletPoint icon="/icons/call-outgoing.svg">
            Neobmedzené volania a správy
            <br />
            <b>do všetkých sietí</b>
          </BulletPoint>
          <BulletPoint icon="/icons/signal.svg">Neobmedzené dáta</BulletPoint>
          <BulletPoint
            icon="/icons/internet-speed.svg"
            secondaryPoint="Maximálna rýchlosť - pripútaj sa!"
          >
            Najvyššia rýchlosť dát
          </BulletPoint>
        </CustomerPlanItem>
        <CustomerPlanItem
          backgroundSrc="/images/plan-item-green.png"
          headline="za 20"
          price={20}
          headlineColor="#11454E"
        >
          <BulletPoint icon="/icons/call-outgoing.svg">
            Neobmedzené volania a správy
            <br />
            <b>do všetkých sietí</b>
          </BulletPoint>
          <BulletPoint icon="/icons/signal.svg">50 GB objem dát</BulletPoint>
          <BulletPoint
            icon="/icons/internet-speed.svg"
            secondaryPoint="Maximálna rýchlosť - pripútaj sa!"
          >
            Najvyššia rýchlosť dát
          </BulletPoint>
        </CustomerPlanItem>
        <CustomerPlanItem
          backgroundSrc="/images/plan-item-white.png"
          headline="za 15"
          price={15}
          textColor="black"
        >
          <BulletPoint icon="/icons/call-outgoing.svg" textColor="black">
            Neobmedzné volania <b>v Telekome</b>
            <br />+ 100 minút a 100 správ
            <br />
            <b>do všetkých sietí</b>
          </BulletPoint>
          <BulletPoint icon="/icons/signal.svg" textColor="black">
            15 GB objem dát
          </BulletPoint>
          <BulletPoint
            icon="/icons/internet-speed.svg"
            secondaryPoint="Maximálna rýchlosť - pripútaj sa!"
            textColor="black"
          >
            Najvyššia rýchlosť dát
          </BulletPoint>
        </CustomerPlanItem>
      </CustomerPlanSection>

      <Stories
        stories={[
          {
            imageSource: "/images/benefits/benefit-1.png",
            // headline: ["WORRY", "FREE"],
            headline: ["BEZ", "VIAZANOSTI"],
            hollowHeadline: [],
            description: "predplatíš si program SWIPE vždy len na 30 dní",
            imageClassName: "object-[20%] lg:object-center",
          },
          {
            imageSource: "/images/benefits/benefit-2.png",
            headline: ["FREE", "NET"],
            description: "3 hodiny denne na vybraných miestach a univerzitách",
            imageClassName: "object-[20%] lg:object-center",
          },
          {
            imageSource: "/images/benefits/benefit-3.png",
            headline: ["FREE", "HOVORY "],
            description: "v sieti Telekom máš hovory úplne zadarmo",
          },
          {
            imageSource: "/images/benefits/benefit-4.png",
            headline: ["FLEXIBILNÝ", "PROGRAM"],
            description: "každých 30 dní si ho môžeš meniť podľa seba",
          },
          {
            imageSource: "/images/benefits/benefit-5.png",
            headline: ["DON'T", "WORRY"],
            description: "za dáta, volania a správy nezaplatíš viac ako 30 €",
          },
        ]}
        headline="benefity"
      />

      <TicketSection
        items={[
          {
            headline: "Glebov koncert",
            points: ["Stretnutie a fotky s Glebom v backstage", "Odvoz pre teba a tvojich kamošov"],
            ticketWinnings: [
              { amount: "1+9", type: "free lístkov pre víťaza" },
              { amount: "3x", type: "väčšia šanca na win ak máš Nekonečný SWIPE" },
            ],
            imageSrc: "/images/tickets/gleb.png",
            textureSrc: "/images/tickets/silver.png",
            ticketType: "SILVER",
          },
          {
            headline: "Rozbaľ to na 100 %",
            points: ["Top SK + CZ festivaly a koncerty", "Párty a kluby", "Žrebujeme každý mesiac"],
            ticketWinnings: [
              { amount: "1+1", type: "free lístkov pre víťaza" },
              { amount: "3x", type: "väčšia šanca na win ak máš Nekonečný SWIPE" },
            ],
            imageSrc: "/images/tickets/concert.png",
            textureSrc: "/images/tickets/bronze.png",
            ticketType: "BRONZE",
          },
          {
            headline: "Párty podľa teba",
            points: [
              "Zorgranizujeme ti párty podľa teba so všetkým, čo k tomu patrí",
              "Odvoz pre teba a tvojich kamošov",
            ],
            ticketWinnings: [
              { amount: "1+9", type: "free lístkov pre víťaza" },
              { amount: "3x", type: "väčšia šanca na win ak máš Nekonečný SWIPE" },
            ],
            imageSrc: "/images/tickets/party.png",
            textureSrc: "/images/tickets/gold.png",
            ticketType: "GOLD",
            isPreparing: true,
          },
        ]}
      />

      <Stories
        stories={[
          {
            imageSource: "/images/special-deals/special-1.png",
            // headline: ["WORRY", "FREE"],
            imageHeadline: {
              src: "/icons/regal-burger.svg",
              className: "w-[9.75rem] h-[4.625rem]",
            },

            description: "k burgru ti vybavíme nápoj, hranolky a omáčku zadarmo",
            // imageClassName: "object-[20%] lg:object-center",
          },
          {
            imageSource: "/images/special-deals/special-2.png",
            imageHeadline: {
              src: "/icons/pelikan.svg",
              className: "w-[11.75rem] h-[3.33969rem]",
            },
            description: "zľava 19 € pri nákupe leteniek cez aplikáciu Pelipecky",
          },
          {
            imageSource: "/images/special-deals/special-3.png",
            imageHeadline: {
              src: "/icons/wolt.svg",
              className: "w-[7.36744rem] h-[2.6875rem]",
            },
            description: "zľava 5 € na prvé 2 objednávky pre všetkých zákazníkov",
          },
        ]}
        headline="MOMENTS"
        hasSecondarySplat={true}
      />

      <CombinedVideoSection>
        <Step>
          Máš od 15 do 28 rokov? Vitaj 👋
          <br /> Či už si potrebuješ preniesť číslo alebo
          <br /> chceš nové,{" "}
          <b>
            všetko vyriešiš v appke, <br /> tak sťahuuuj.
          </b>
        </Step>
        <Step>
          <b>Vyber si svoj SWIPE,</b> my si{" "}
          <b>
            overíme
            <br /> tvoje údaje
          </b>{" "}
          a tebe stačí už len{" "}
          <b>
            vyplniť
            <br /> platobnú kartu
          </b>{" "}
          a SWIPE bude naplno
          <br /> tvoj - let’s gooo! 🚀
        </Step>
        <Step>
          <b>Užívaj si 30 dní podľa teba</b> 🔥
          <br /> Program si môžeš kedykoľvek zmeniť,
          <br /> stopnúť alebo si dokúpiť balíčky
          <br /> navyše.
        </Step>
      </CombinedVideoSection>

      <Videos
        videos={[
          {
            videoHeadline: "Čo všetko ti prináša mobilný program Swipe?",
            youtubeId: "uy6FyZ8x0u4",
          },
        ]}
      />

      <Partners />

      <FaqSection>
        <FaqItem index={1} question="wrgegegegr">
          erjginerognerog
        </FaqItem>
        <FaqItem index={2} question="wrgegegegr">
          erjginerognerog
        </FaqItem>
        <FaqItem index={3} question="wrgegegegr">
          erjginerognerog
        </FaqItem>
        <FaqItem index={4} question="wrgegegegr">
          erjginerognerog
        </FaqItem>
      </FaqSection>
    </main>
  );
}
