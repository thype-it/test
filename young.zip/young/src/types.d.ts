type Label = {
  label: string;
  businessName: string;
};

type Rateplan = {
  labels: Label[];
  name: string;
  voice: number;
  messages: number;
  data: number;
  dataRoamingFup: number;
  speed: number;
  price: number;
};

type Story = {
  imageSource: string;
  headline?: string[];
  imageHeadline?: SvgStoryImage;
  hollowHeadline?: string[];
  description: string;
  imageClassName?: string;
};

type SvgStoryImage = {
  src: string;
  className?: string;
};

type Video = {
  videoHeadline: string;
  youtubeId: string;
};

type Video = {
  videoHeadline: string;
  youtubeId: string;
};
