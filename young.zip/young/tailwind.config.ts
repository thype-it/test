import type { Config } from "tailwindcss";

const config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: {
        DEFAULT: ".8rem",
        md: "5.5rem",
        xl: "5.5rem",
      },
    },
    extend: {
      //Theme customization:
      colors: {
        primary: "#E20074",
      },
      scale: {
        "101": "1.02",
        "99": "0.99",
      },
      spacing: {
        "112": "28rem",
        "3lvh": "300lvh",
        "hero-max-h": "3380px",
      },
      objectPosition: {
        "center-top-margin": "50% 36%",
      },
      screens: {
        "2xl": "1400px",
      },
      //UI libraries:
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
      fontFamily: {
        teleneo: ["var(--font-teleneo)"],
      },
      fontSize: {
        "story-content-header": [
          "1.75rem",
          {
            lineHeight: "normal",
            letterSpacing: "0.35rem",
            fontWeight: "800",
          },
        ],
        "story-headline": [
          "3rem",
          {
            lineHeight: "2.5rem",
            fontWeight: "800",
          },
        ],
        "story-description": [
          "0.8125rem",
          {
            lineHeight: "1.25rem",
          },
        ],
        "rateplan-price": [
          "2.5rem",
          {
            lineHeight: "2.75rem",
            fontWeight: "800",
          },
        ],
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config;

export default config;
