/** @type {import('next').NextConfig} */
const nextConfig = {
  //   basePath: "/swipe",
  //   output: "export",
};

export default nextConfig;
